<!DOCTYPE html>
<html>
    <title>Activity 12</title>
</html>

<body>
    <form action="update.php" method="post">
    <?php
    require_once("connect.php");
    $id=$_GET['id_num'];

    $query = mysqli_query($connect,"select * from signup where id='$id';");
    $row = mysqli_fetch_array($query);
    ?>

    <label for="fname">Name:</label>
    <input type="hidden" name="id" value="<?php echo $row['id'];?>" /><br>
    <input type="text" name="fname" value="<?php echo $row['name'];?>" /><br>
<label for="sma">Social Media Acct:</label>
    <input type="checkbox" id="fb" name="sma[]" value="FB" />
    <label for="fb">FB</label>
    <input type="checkbox" id="ig" name="sma[]" value="IG" />
    <label for="ig">IG</label>
    <input type="checkbox" id="tt" name="sma[]" value="TT" />
    <label for="tt">Tiktok</label> <br>
    <input type="submit" name="submit" />
    </form><br><br>

</body>