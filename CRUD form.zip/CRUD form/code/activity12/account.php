<table border=1 cellspacing=0>
        <tr>
            <td><b>ID Num</b></td>
            <td><b>Name</b></td>
            <td><b>Birthday</b></td>
            <td><b>Gender</b></td>
            <td><b>PL</b></td>
            <td><b>Status</b></td>
            <td><b>Action</b></td>
        </tr>
        <?php
        require_once('connect.php');

        $query=mysqli_query($connect,"select * from registration");
        
            ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['dname']; ?></td>
                <td><?php echo $row['dname']; ?></td>
                <td><?php echo $row['bday']; ?></td>
                <td><?php echo $row['gender']; ?></td>
                 <td>
                    <a href="update_form.php?id_num=<?php echo  $row['id']; ?>">Edit</a>&nbsp;
                    <a href="delete.php?id_num=<?php echo $row['id']?>">Delete</a>
                </td>
            </tr>
        <?php
        
        ?>
    </table>