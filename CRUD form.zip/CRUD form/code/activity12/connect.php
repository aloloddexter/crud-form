<?
$connect= mysqli_connect("localhost", "root","","registration")
or die("Cannot connect to the database");
?>